/*
    QuadSynth.cpp  

    Implementation of the QuadSynth and related classes.

    ---------------------------------------------------------------------------
 
    Copyright (C) 2016, Cornfield Electronics, Inc.
 
    This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 
    Unported License.
 
    To view a copy of this license, visit
    http://creativecommons.org/licenses/by-sa/3.0/
 
    Created by Bill Alessi & Mitch Altman.
 
   ---------------------------------------------------------------------------
*/

#include "Audio.h"
#include "QuadSynth.h"

/******************************************************************************
 *
 *                              QuadVoice 
 *
 ******************************************************************************/

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadVoice::evHandler
 *
 *  Desc:  Handle an onboard event.
 *
 *  Args:  ev               - onboard event
 *
 *  Rets:  status           - true if the event was handled
 *
 *----------------------------------------------------------------------------*/      

boolean QuadVoice::evHandler( obEvent e )         
{
   switch ( e.type() )                 // branch on event type
   {
      case KEY_DOWN:                   // a key has been pressed
      case KEY_UP:                     // key has been released

         return false;                 // pass to lower mode on stack

      default:                         // pass on unhandled events
                                             
         return XVoice::evHandler(e);
   }
}

#ifdef CONSOLE_OUTPUT
const char *QuadVoice::prompt()                   
{
   switch( voxNum )
   {
      case 0:  return CONSTR("0");
      case 1:  return CONSTR("1");
      case 2:  return CONSTR("2");
      case 3:  return CONSTR("3");
      default: return XVoice::prompt();
   }
}
#endif

/******************************************************************************
 *
 *                                QuadSynth 
 *
 ******************************************************************************/

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setup
 *
 *  Desc:  Initialize synth. 
 *
 *  Memb:  vox[]            - component voices
 *
 *  Note:  This call-back method is automatically executed by ardutouch_setup()
 *         after system resources have been initialized. It is best to put your
 *         synth's initialization code here, and not in the constructor.
 *
 *----------------------------------------------------------------------------*/      

void QuadSynth::setup() 
{ 
   for ( byte i = 0; i < NumVox; i++ )       // allocate and number voices
   {
      vox[i] = new QuadVoice();
      vox[i]->voxNum = i;
   }
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::charEv
 *
 *  Desc:  Process a character event.
 *
 *  Args:  code             - character to process
 *
 *  Memb:  vox[]            - component voices
 *
 *  Rets:  status           - true if character was handled
 *
 *----------------------------------------------------------------------------*/      

boolean QuadSynth::charEv( char code )
{
   switch( code )
   {
      #ifdef INTERN_CONSOLE                  // compile cases needed by macros

      case '0':                              // 0 thru 3 push respective voices
      case '1':
      case '2':
      case '3':

         console.pushMode( vox[code-'0'] );
         break;

      #endif
                                             // reset
      case '!':

         StereoSynth::charEv( code );
         for ( byte i = 0; i < NumVox; i++ )
            vox[i]->reset();
         break;

      case '.':                              // mute
      case '<':                              // unmute

      {
         byte chnlVol = ( code == '.' ? 0 : vol );
         for ( byte i = 0; i < NumVox; i++ )
            vox[i]->setGlobVol( chnlVol );
      }  
         
      // fall thru to SteroSynth

      default:

         return StereoSynth::charEv( code );
   }
   return true;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::dynamics
 *
 *  Desc:  Perform a dynamic update:
 *
 *         1) execute a noteOn for the next defered voice, if any.
 *         2) decrement the index for next defered voice
 *         3) call each voice's dynamic update method.
 *
 *  Memb: +deferVoc         - if nonzero, execute noteOn for vox[deferVoc-1] 
 *         vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::dynamics()  
{  
   if ( deferVoc )         // execute noteOn for next defered voice
   {
      --deferVoc;
      vox[ deferVoc ]->noteOn( lastNote );
   }
   vox[0]->dynamics();    
   vox[1]->dynamics();    
   vox[2]->dynamics();    
   vox[3]->dynamics();    
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::evHandler
 *
 *  Desc:  Handle an onboard event.
 *
 *  Args:  ev               - onboard event
 *
 *  Memb:  vox[]            - component voices
 *
 *  Rets:  status           - true if the event was handled
 *
 *----------------------------------------------------------------------------*/      

boolean QuadSynth::evHandler( obEvent e )            
{
   switch ( e.type() )                       // branch on event type
   {
      case KEY_DOWN:                         // a key has been pressed

         noteOn( e.getKey() );
         break;

      case KEY_UP:                           // key has been released

         for ( byte i = 0; i < NumVox; i++ )
            vox[i]->noteOff();                  
         break;

      default:                               // pass on unhandled events
                                             
         return StereoSynth::evHandler(e);
      }
   return true;                     
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::noteOn
 *
 *  Desc:  Propagate a noteOn to each of the synth's voices. 
 *
 *  Memb: +deferVoc         - next dynamics() will call vox[deferVoc-1]->noteOn()
 *                            (if deferVoc != 0)
 *        +lastNote         - last note played
 *
 *  Note:  The actual note played by each voice depends on the input note plus
 *         whatever offset was specified for that voice in the last call to
 *         QuadSynth::setVoicing(). 
 *
 *         QuadSynth uses an incremental algorithm for performing noteOns by
 *         distributing their execution across the next 4 dynamic updates.
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::noteOn( key newNote )
{
   deferVoc = NumVox;                        // set for defered noteOns
   lastNote = newNote;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::output
 *
 *  Desc:  Write (stereo) output to a pair of audio buffers.
 *
 *  Args:  bufL             - ptr to left audio buffer  
 *         bufR             - ptr to right audio buffer  
 *
 *  Glob:  audioBufSz       - size of system audio buffers
 *
 *  Memb:  vox[]            - component voices
 *
 *  Note:  The outputs from voice 0 and voice 1 are combined in left buffer.
 *         The outputs from voice 2 and voice 3 are combined in right buffer.
 *
 *----------------------------------------------------------------------------*/      

void QuadSynth::output( char *bufL, char *bufR )
{  
   int sum;

   char  buf0[ audioBufSz ];     // temp buffer for for holding vox[0] output
   char  buf3[ audioBufSz ];     // temp buffer for for holding vox[3] output

   // combine vox[0] and vox[1] output in bufL
   // combine vox[2] and vox[3] output in bufR

   vox[0]->output( &buf0[0] ); 
   vox[1]->output( bufL ); 
   vox[2]->output( bufR ); 
   vox[3]->output( &buf3[0] ); 

   for ( byte i = 0 ; i < audioBufSz; i++ )
   {
      sum = bufL[ i ] + buf0[ i ];
      bufL[i] = sum >> 1;
      sum = bufR[ i ] + buf3[ i ];
      bufR[i] = sum >> 1;
   }
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::reTrigger
 *
 *  Desc:  Retrigger all voices. 
 *
 *  Memb: +deferVoc         - next dynamics() will call vox[deferVoc-1]->noteOn()
 *                            (if deferVoc != 0)
 *         vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::reTrigger()                          
{
   for ( byte i = 0; i < NumVox; i++ )       // call noteOff for all voices
      vox[i]->noteOff();

   // set deferVoc so that noteOns() will be called in subsequent dynamics() 

   deferVoc = NumVox;                        
}  

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setAttack
 *
 *  Desc:  Set the attack time of the amplitude envelope for all voices.
 *
 *  Args:  attack           - attack time
 *
 *  Memb:  vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::setAttack( byte attack )
{
   for ( byte i = 0; i < NumVox; i++ )
      vox[i]->envAmp.setAttack( attack );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setDecay
 *
 *  Desc:  Set the decay time of the amplitude envelope for all voices.
 *
 *  Args:  decay            - decay time
 *
 *  Memb:  vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::setDecay( byte decay )
{
   for ( byte i = 0; i < NumVox; i++ )
      vox[i]->envAmp.setDecay( decay );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setRelease
 *
 *  Desc:  Set the release time of the amplitude envelope for all voices.
 *
 *  Args:  release          - release time
 *
 *  Memb:  vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::setRelease( byte release )
{
   for ( byte i = 0; i < NumVox; i++ )
      vox[i]->envAmp.setRelease( release );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setSustain
 *
 *  Desc:  Set the sustain level of the amplitude envelope for all voices.
 *
 *  Args:  sustain          - sustain level
 *
 *  Memb:  vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::setSustain( byte sustain )
{
   for ( byte i = 0; i < NumVox; i++ )
      vox[i]->envAmp.setSustain( sustain );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setVoicing
 *
 *  Desc:  Set the transposition interval for each voice.
 *
 *  Args:  voicing          - transposition intervals per voice
 *
 *  Memb:  vox[]            - component voices
 *
 *  Note:  A voicing specifies the transposition interval for each voice.
 *         When a noteOn is received by the synth, it will be transposed
 *         per voice by the number of intervals specified in the voicing.
 *         For example, if the synth has its voicing set to (-12, 0, 7, 12)
 *         and receives a noteOn for the note C4 then the resultant notes 
 *         per voice will be:
 *
 *             vox[0] - C3
 *             vox[1] - C4
 *             vox[2] - G4
 *             vox[3] - C5
 *
 *----------------------------------------------------------------------------*/

void QuadSynth::setVoicing( Voicing v )
{
   for ( byte i = 0; i < NumVox; i++ )   
      vox[i]->xpose = v[i];
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadSynth::setVol
 *
 *  Desc:  Set the volume level.
 *
 *  Args:  vol              - volume level
 *
 *  Memb: +vol              - volume level (0:255)
 *         vox[]            - component voices
 *
 *----------------------------------------------------------------------------*/      

void QuadSynth::setVol( byte vol )
{
   StereoSynth::setVol( vol );
   if ( ! amMute() )
      for ( byte i = 0; i < NumVox; i++ )   
         vox[i]->setGlobVol( vol );
}


/******************************************************************************
 *
 *                               QuadPanSynth 
 *
 ******************************************************************************/

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::setup
 *
 *  Desc:  Initialize synth. 
 *
 *  Memb: +panControl       - dynamic controller of panPos
 *
 *  Note:  This call-back method is automatically executed by ardutouch_setup()
 *         after system resources have been initialized. It is best to put your
 *         synth's initialization code here, and not in the constructor.
 *
 *----------------------------------------------------------------------------*/      

void QuadPanSynth::setup() 
{ 
   QuadSynth::setup();
   panControl = new PanControl( &this->panPos );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::charEv
 *
 *  Desc:  Process a character event.
 *
 *  Args:  code             - character to process
 *
 *  Memb: +pan[]            - component voices in pan order
 *         panControl       - dynamic controller of panPos
 *         vox[]            - component voices
 *
 *  Rets:  status           - true if character was handled
 *
 *----------------------------------------------------------------------------*/      

boolean QuadPanSynth::charEv( char code )
{
   switch( code )
   {
      #ifdef INTERN_CONSOLE   // compile cases needed by macros

      case 'M':
      {
         char *newMap;
         if ( console.getStr( CONSTR("panMap"), &newMap ) )
            setMap( newMap );
         break;
      }
      case 'P':
         
         console.pushMode( panControl );
         break;   
      
      #endif

      #ifdef CONSOLE_OUTPUT   // compile cases that display to console 

      case chrInfo:

         QuadSynth::charEv( chrInfo );

         console.romprint( CONSTR("{panMap ") );
         for ( byte i = 0; i < NumVox; i++ )
            console.print( (char )('0' + pan[i]->voxNum) );
         console.romprint( CONSTR("} ") );

         panControl->brief();
         break;

      #endif

      case '!':

         QuadSynth::charEv('!');
         for ( byte i = 0; i < NumVox; i++ )
            pan[i] = vox[i];
         panControl->reset();
         break;

      default:

         return QuadSynth::charEv( code );
   }
   return true;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::dynamics
 *
 *  Desc:  Perform a dynamic update.
 *
 *  Memb:  panControl       - dynamic controller of panPos
 *
 *----------------------------------------------------------------------------*/

void QuadPanSynth::dynamics() 
{  
   QuadSynth::dynamics();
   panControl->dynamics();
}

#ifdef KEYBRD_MENUS
char QuadPanSynth::menu( key k )   
{
   switch ( k.position() )
   {
      case  7: return 'P';                // push Pan control
      default: return QuadSynth::menu(k);
   }
}
#endif

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::output
 *
 *  Desc:  Write (stereo) output to a pair of audio buffers.
 *
 *  Args:  bufL             - ptr to left audio buffer  
 *         bufR             - ptr to right audio buffer  
 *
 *  Glob:  audioBufSz       - size of system audio buffers
 *
 *  Memb:  pan[]            - component voices in pan order
 *         panPos           - pan position for voice pan[1] 
 *
 *  Note:  Output from voice pan[0] will be written to the left buffer.
 *         Output from voice pan[3] will be written to the right buffer.
 *
 *         Output from voices pan[1] & pan[2] will be divided between the
 *         left and right buffers depending on the value of panPos. 
 *
 *         panPos is a scalar which determines how much of voice pan[1] is 
 *         written to the left buffer (the remainder is written to the right 
 *         buffer). Voice pan[2] is panned as the stereo complement of voice
 *         pan[1] -- i.e., if voice pan[1] is 30% in the left buffer and 70%
 *         in the right buffer, then voice pan[2] is 70% in the left buffer
 *         and 30% in the right buffer.
 *
 *----------------------------------------------------------------------------*/      

void QuadPanSynth::output( char *bufL, char *bufR )
{  
   // voice 0 output is always all in left channel
   // voice 3 output is always all in right channel
   //
   // voice 1 & 2 are mixed between the two channels based on panPos

   // pan the four voices so that:
   //
   //    bufL = ( pan[0] + (255-panPos)*pan[1] + panPos*pan[2] ) / 2
   //    bufR = ( pan[3] + (255-panPos)*pan[2] + panPos*pan[1] ) / 2
   //

   char  buf0[ audioBufSz ];    // temp buffer for for holding pan[0] output
   char  buf3[ audioBufSz ];    // temp buffer for for holding pan[3] output

   int  sum;                              // temp sum register
   int  sum1_2;                           // sum of voice 1 & 2 output
   int  sum1L_2L;                         // left component of pan[1+2]
   Int  pan1L;                            // left component of pan[1]
   Int  pan2L;                            // left component of pan[2]
   byte coPanning;                        // complement of panPos

   coPanning = 255 - panPos;

   pan[0]->output( &buf0[0] ); 
   pan[1]->output( bufL ); 
   pan[2]->output( bufR ); 
   pan[3]->output( &buf3[0] ); 

   for ( byte i = 0 ; i < audioBufSz; i++ )
   {
      pan1L.val  = coPanning;
      pan1L.val *= bufL[i];
      pan2L.val  = panPos;
      pan2L.val *= bufR[i];

      sum1_2     = bufL[i] + bufR[i];
      sum1L_2L   = pan1L._.msb + pan2L._.msb;

      sum        = buf0[i] + sum1L_2L;
      bufL[i]    = sum >> 1;

      sum        = buf3[ i ] + sum1_2  - sum1L_2L;
      bufR[i]    = sum >> 1;
   }

}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::setMap
 *
 *  Desc:  Set the panning map for the component voices.
 *
 *  Args:  mapStr           - string specifying pan order for voices
 *
 *  Memb: +pan[]            - component voices in pan order
 *         vox[]            - component voices
 *
 *  Note:  A valid mapStr is 4 characters long (+ null terminal char), and
 *         consists of the digits "0", "1", "2", and "3" appearing once in 
 *         any order. 
 *
 *----------------------------------------------------------------------------*/      

void QuadPanSynth::setMap( char *mapStr )
{
   byte i;

   // reject map if length of string != NumVox

   if ( mapStr[ NumVox ] != 0 )           
      return;   

   // initialize all members of transfer array to NOT_PRESENT

   const byte NOT_PRESENT = 255;
   byte xfer[ NumVox ];
   for ( i = 0; i < NumVox; i++ )
      xfer[i] = NOT_PRESENT;

   // iterate through characters of mapStr and populate transfer array

   i = 0;
   while ( mapStr[i] != 0 )
   {
      byte digit = mapStr[i]-'0';
      if ( digit >= NumVox ) return;      // reject on bad digit
      xfer[digit] = i;
      i++;
   }
      
   // reject map if any element of xfer[] is not present

   for ( i = 0; i < NumVox; i++ )
      if ( xfer[i] == NOT_PRESENT ) 
         return;

   // remap pan[]

   i = 0;
   while ( mapStr[i] != 0 )
   {
      byte digit = mapStr[i]-'0';
      pan[i] = vox[digit];
      i++;
   }
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadPanSynth::setPanPos
 *
 *  Desc:  Set the panning position for voices pan[1/2].
 *
 *  Args:  panPos           - pan position for voices pan[1/2].
 *
 *  Memb:  panControl       - dynamic controller of panPos
 *
 *  Note:  panPos is a scalar which determines how much of voice pan[1] is 
 *         written to the left buffer (the remainder is written to the right 
 *         buffer). Voice pan[2] is panned as the stereo complement of voice
 *         pan[1] -- i.e., if voice pan[1] is 30% in the left buffer and 70%
 *         in the right buffer, then voice pan[2] is 70% in the left buffer
 *         and 30% in the right buffer.
 *
 *----------------------------------------------------------------------------*/      

void QuadPanSynth::setPanPos( byte panPos )
{
   panControl->setRestPos( panPos );
}


/******************************************************************************
 *
 *                          QuadDualPanSynth 
 *
 ******************************************************************************/

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadDualPanSynth::setup
 *
 *  Desc:  Initialize synth. 
 *
 *  Memb: +xpanControl      - dynamic controller of xpanPos
 *
 *  Note:  This call-back method is automatically executed by ardutouch_setup()
 *         after system resources have been initialized. It is best to put your
 *         synth's initialization code here, and not in the constructor.
 *
 *----------------------------------------------------------------------------*/      

void QuadDualPanSynth::setup() 
{ 
   QuadPanSynth::setup();
   xpanControl = new XPanControl( &this->xpanPos );
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadDualPanSynth::charEv
 *
 *  Desc:  Process a character event.
 *
 *  Args:  code             - character to process
 *
 *  Memb:  xpanControl      - dynamic controller of xpanPos
 *
 *  Rets:  status           - true if character was handled
 *
 *----------------------------------------------------------------------------*/      

boolean QuadDualPanSynth::charEv( char code )    
{
   switch( code )
   {
      #ifdef INTERN_CONSOLE   // compile cases needed by macros

      case 'X':
         
         console.pushMode( xpanControl );
         break;   
      
      #endif

      #ifdef CONSOLE_OUTPUT   // compile cases that display to console 

      case chrInfo:

         QuadPanSynth::charEv( chrInfo );
         xpanControl->brief();
         break;

      #endif

      case '!':

         QuadPanSynth::charEv('!');
         xpanControl->reset();
         break;

      default:

         return QuadPanSynth::charEv( code );
   }
   return true;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadDualPanSynth::dynamics
 *
 *  Desc:  Perform a dynamic update.
 *
 *  Memb:  xpanControl      - dynamic controller of xpanPos
 *
 *----------------------------------------------------------------------------*/

void QuadDualPanSynth::dynamics()     
{  
   QuadPanSynth::dynamics();
   xpanControl->dynamics();
}

#ifdef KEYBRD_MENUS
char QuadDualPanSynth::menu( key k )   
{
   switch ( k.position() )
   {
      case  8: return 'X';                // push XPan control
      default: return QuadPanSynth::menu(k);
   }
}
#endif

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadDualPanSynth::output
 *
 *  Desc:  Write (stereo) output to a pair of audio buffers.
 *
 *  Args:  bufL             - ptr to left audio buffer  
 *         bufR             - ptr to right audio buffer  
 *
 *  Glob:  audioBufSz       - size of system audio buffers
 *
 *  Memb:  pan[]            - component voices in pan order
 *         panPos           - pan position for voices pan[1/2] 
 *         xpanPos          - pan position for voices pan[0/3] 
 *
 *  Note:  Output from voices pan[1] & pan[2] will be divided between the
 *         left and right buffers depending on the value of panPos. 
 *
 *         Output from voices pan[0] & pan[3] will be divided between the
 *         left and right buffers depending on the value of xpanPos. 
 *
 *         panPos is a scalar which determines how much of voice pan[1] is 
 *         written to the left buffer (the remainder is written to the right 
 *         buffer). Voice pan[2] is panned as the stereo complement of voice
 *         pan[1] -- i.e., if voice pan[1] is 30% in the left buffer and 70%
 *         in the right buffer, then voice pan[2] is 70% in the left buffer
 *         and 30% in the right buffer.
 *
 *         xpanPos is operable on voices pan[0] and pan[3], in the same way 
 *         that panPos is operable on voices pan[1] and pan[2]
 *
 *----------------------------------------------------------------------------*/      

void QuadDualPanSynth::output( char *bufL, char *bufR ) 
{  
   // voice 0 & 3 are mixed between the two channels based on xpanPos
   // voice 1 & 2 are mixed between the two channels based on panPos

   // pan the four voices so that:
   //
   //    bufL = ( (255-panPos) *pan[1] +  panPos*pan[2] 
   //             (255-xpanPos)*pan[0] + xpanPos*pan[3] ) / 2
   //
   //    bufR = ( (255-panPos) *pan[2] +  panPos*pan[1] 
   //             (255-xpanPos)*pan[3] + xpanPos*pan[0] ) / 2

   char  buf0[ audioBufSz ];    // temp buffer for for holding pan[0] output
   char  buf3[ audioBufSz ];    // temp buffer for for holding pan[3] output

   int  sum;                              // temp sum register
   int  sum1_2;                           // sum of voice 1 & 2 output
   int  sum1L_2L;                         // left component of pan[1+2]
   Int  pan1L;                            // left component of pan[1]
   Int  pan2L;                            // left component of pan[2]
   byte coPanning;                        // complement of panPos

   int  sum0_3;                           // sum of voice 0 & 3 output
   int  sum0L_3L;                         // left component of pan[0+3]
   Int  pan0L;                            // left component of pan[0]
   Int  pan3L;                            // left component of pan[3]
   byte coXPanning;                       // complement of xpanPos

   coPanning  = 255 - panPos;
   coXPanning = 255 - xpanPos;

   pan[0]->output( &buf0[0] ); 
   pan[1]->output( bufL ); 
   pan[2]->output( bufR ); 
   pan[3]->output( &buf3[0] ); 

   for ( byte i = 0 ; i < audioBufSz; i++ )
   {
      pan1L.val  = coPanning;
      pan1L.val *= bufL[i];
      pan2L.val  = panPos;
      pan2L.val *= bufR[i];

      sum1_2     = bufL[i] + bufR[i];
      sum1L_2L   = pan1L._.msb + pan2L._.msb;

      pan0L.val  = coXPanning;
      pan0L.val *= buf0[i];
      pan3L.val  = xpanPos;
      pan3L.val *= buf3[i];

      sum0_3     = buf0[i] + buf3[i];
      sum0L_3L   = pan0L._.msb + pan3L._.msb;

      sum        = sum0L_3L + sum1L_2L;
      bufL[i]    = sum >> 1;

      sum        = sum0_3 + sum1_2 - sum0L_3L - sum1L_2L;
      bufR[i]    = sum >> 1;
   }

}

/*----------------------------------------------------------------------------*
 *
 *  Name:  QuadDualPanSynth::setXPanPos
 *
 *  Desc:  Set the panning position for voices pan[0/3].
 *
 *  Args:  xpanPos          - pan position for voices pan[0/3].
 *
 *  Memb:  xpanControl      - dynamic controller of xpanPos
 *
 *  Note:  xpanPos is a scalar which determines how much of voice pan[0] is 
 *         written to the left buffer (the remainder is written to the right 
 *         buffer). Voice pan[3] is panned as the stereo complement of voice
 *         pan[1] -- i.e., if voice pan[0] is 30% in the left buffer and 70%
 *         in the right buffer, then voice pan[3] is 70% in the left buffer
 *         and 30% in the right buffer.
 *
 *----------------------------------------------------------------------------*/      

void QuadDualPanSynth::setXPanPos( byte xpanPos )
{
   xpanControl->setRestPos( xpanPos );
}

/******************************************************************************
 *       
 *                                PanControl
 *
 ******************************************************************************/

PanControl::PanControl( byte *panPos )
{
   this->panPos = panPos;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  PanControl::calcExtent
 *
 *  Desc:  Compute the panning extent.
 *
 *  Memb: +center           - panning center
 *        +diameter         - panning diameter
 *         pinned           - if true, pan is centered around restPos
 *         restPos          - position when at rest
 *
 *----------------------------------------------------------------------------*/      

void PanControl::calcExtent()
{
   if ( pinned )
   {
      center = restPos;
      if ( center < 128 )
         diameter = 2 * center;
      else
         diameter = 2 * (255 - center);
   }
   else
   {
      center   = 128;
      diameter = 255;
   }
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  PanControl::charEv
 *
 *  Desc:  Process a character event.
 *
 *  Args:  code             - character to process
 *
 *  Ext:  +*panPos          - current pan position
 *
 *  Memb:  pinned           - if true, pan is centered around restPos
 *         restPos          - position when at rest
 *
 *  Rets:  status           - true if character was handled
 *
 *----------------------------------------------------------------------------*/      

boolean PanControl::charEv( char code )
{
   switch( code )
   {
      case lfoOnDepth:                    // depth has been set/changed

         calcExtent();                    // re-compute panning diameter
         break;

      #ifdef INTERN_CONSOLE               // compile cases needed by macros

      case 'p':                           // pin panning center to rest position

         setPinned( true );
         break;

      case 'r':                           // set rest position
      case 'P':
      {
         byte newRestPos;
         if ( console.getByte( CONSTR("restPos"), &newRestPos ) )
            setRestPos( newRestPos );
         break;
      }
      case 'u':                           // unpin panning center from rest position

         setPinned( false );
         break;

      #endif

      case '.':                           // mute panning effect

         LFO::charEv( code );
         *panPos = restPos;
         break;

      case '!':                           // unmute panning effect

         LFO::charEv( code );
         setPinned( false );
         setDepth( 1.0 );
         break;

      #ifdef CONSOLE_OUTPUT   // compile cases that display to console 

      case chrBrief:

         LFO::charEv( chrBrief );
         break;

      case chrInfo:

         LFO::charEv( chrInfo );
         console.newlntab();
         console.infoByte( CONSTR("restPos"), restPos );
         console.print('.');
         if ( ! pinned )
            console.romprint( CONSTR("un") );
         console.romprint( CONSTR("pinned.") );
         break;

      #endif

      default:

         return LFO::charEv( code );
   }
   return true;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  PanControl::evaluate
 *
 *  Desc:  Compute the pan position given current osc and pan parameters.
 *
 *  Ext:  +*panPos          - current pan position
 *
 *  Memb:  center           - panning center
 *         diameter         - panning diameter
 *         depth            - oscillation depth (0.0 - 1.0)
 *         pos              - cur position within oscillation diameter
 *
 *----------------------------------------------------------------------------*/      

void PanControl::evaluate()  
{
   // the folowing code is equivalent to:
   //
   //  double panPos = center + ( radius * ( pos - depth/2 ) );
   //

   double offset = ( diameter * ( 2 * pos - depth )  ) / 2;
   double evPos  = center  + offset;
   *panPos       = evPos;
}

#ifdef KEYBRD_MENUS
char PanControl::menu( key k )
{
   switch ( k.position() )
   {
      case  1: return 'p';                   // pin panning center to rest pos
      case  3: return 'u';                   // unpin panning center from rest pos
      case  4: return 'r';                   // set rest position
      default: return LFO::menu( k );
   }
}
#endif

#ifdef CONSOLE_OUTPUT
const char *PanControl::prompt() 
{
   return CONSTR("Pan");
}
#endif

/*----------------------------------------------------------------------------*
 *
 *  Name:  PanControl::setPinned
 *
 *  Desc:  Pin or unpin the panning center to the rest position.
 *
 *  Args:  pinned           - if true, pin panning center to the rest position.
 *
 *  Memb:  pinned           - if true, pan is centered around restPos
 *
 *  Note:  If pinning == false, then panning center is 128, regardless of what
 *         the rest position is. 
 *
 *----------------------------------------------------------------------------*/      

void PanControl::setPinned( boolean pinned )
{
   this->pinned = pinned;
   calcExtent();
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  PanControl::setRestPos
 *
 *  Desc:  Set the panning position when at rest.
 *
 *  Args:  restPos          - panning position when at rest
 *
 *  Ext:  +*panPos          - current pan position
 *
 *  Memb: +restPos          - position when at rest
 *
 *  Note: The rest position is relevant in 2 cases:
 *
 *    1) Panning is muted
 *    2) Panning is unmuted, but pinned ( restPos is panning center )
 *
 *----------------------------------------------------------------------------*/      

void PanControl::setRestPos( byte restPos )
{
   this->restPos = restPos;
   *panPos       = restPos;
   calcExtent();
}

/******************************************************************************
 *       
 *                                XPanControl
 *
 ******************************************************************************/

XPanControl::XPanControl( byte *panPos )
{
   this->panPos = panPos;
}
   
#ifdef CONSOLE_OUTPUT
const char *XPanControl::prompt()        
{
   return CONSTR("XPan");
}
#endif

