/*
    QuadSynth.h  

    Declaration of the QuadSynth and related classes.

    ---------------------------------------------------------------------------
 
    Copyright (C) 2016, Cornfield Electronics, Inc.
 
    This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 
    Unported License.
 
    To view a copy of this license, visit
    http://creativecommons.org/licenses/by-sa/3.0/
 
    Created by Bill Alessi & Mitch Altman.
 
   ---------------------------------------------------------------------------
*/

#ifndef QUADSYNTH_H_INCLUDED
#define QUADSYNTH_H_INCLUDED

#include "Synth.h"
#include "Voice.h"

/* -------------------------------------------------------------------------- */

class QuadVoice : public XVoice          
{
   public:

   byte  voxNum;                          // voice # 

   boolean evHandler( obEvent e );        // event handler

   #ifdef CONSOLE_OUTPUT
   const char *prompt();                  // return object's prompt string
   #endif

} ;

class PanControl : public LFO
{
   protected:

   byte  *panPos;                         // current pan position 

   byte  restPos;                         // pan position when at rest
   byte  center;                          // panning center
   byte  diameter;                        // panning diameter

   boolean pinned;                        // pan is centered around restPos

   public:

   PanControl() {}                        // null constructor

   PanControl( byte *panPos );            // constructor 

   void    calcExtent();                  // calculate panning extent
   boolean charEv( char code );           // handle a character event
   void    evaluate();                    // compute panPos from osc position
   void    setPinned( boolean );          // set/unset pinned state
   void    setRestPos( byte );            // set the rest position

   #ifdef KEYBRD_MENUS
   char    menu( key );                   // map key event to character 
   #endif

   #ifdef CONSOLE_OUTPUT
   const char *prompt();                  // return object's prompt string
   #endif

} ;

class XPanControl : public PanControl
{
   public:

   XPanControl( byte *panPos );           // constructor 
   
   #ifdef CONSOLE_OUTPUT
   const char *prompt();                  // return object's prompt string
   #endif

} ;


class QuadSynth : public StereoSynth
{
   public:

   static const byte NumVox = 4;          // # of component voices 

   typedef char Voicing[ NumVox ];        // transposition intervals per voice


   protected:

   QuadVoice *vox[ NumVox ];              // component voices 

   key   lastNote;                        // last note played
   byte  deferVoc;                        // call vox[deferVoc-1]->noteOn()
                                          // at next dynamic update
   public:

   void setup();                          // initialize synth 

   boolean charEv( char );                // handle a character event
   void dynamics();                       // perform a dynamic update
   boolean evHandler( obEvent );          // event handler
   virtual void noteOn( key );            // play a note
   void output( char *, char * );         // output 1 buffer of audio
   void reTrigger();                      // retrigger all voices
   void setAttack( byte attack );         // set ampEnv attack for all voices
   void setDecay( byte decay );           // set ampEnv decay for all voices
   void setRelease( byte release );       // set ampEnv release for all voices
   void setSustain( byte sustain );       // set ampEnv sustain for all voices
   void setVoicing( Voicing v );          // set transposition intervals per voice
   void setVol( byte vol );               // set synth volume

} ;                                     

class QuadPanSynth : public QuadSynth             
{
   protected:

   PanControl *panControl;                // dynamic controller of panPos

   QuadVoice *pan[ NumVox ];              // voices in pan order

   byte  panPos;                          // pan position for voices pan[1/2] 

   public:

   void setup();                          // initialize synth 

   boolean charEv( char code );           // handle a character event
   void dynamics();                       // perform a dynamic update
   void output( char *bufL, char *bufR ); // output 1 buffer of audio
   void setMap( char *mapStr );           // set the voice panning order
   void setPanPos( byte panPos );         // set the pan position : pan[1/2]

   #ifdef KEYBRD_MENUS
   char menu( key k );                    // map key event to character
   #endif

} ;

class QuadDualPanSynth : public QuadPanSynth             
{
   protected:

   XPanControl *xpanControl;

   byte  xpanPos;                         // pan position for voices pan[0/3]

   public:

   void setup();                          // initialize synth 

   boolean charEv( char code );           // handle a character event
   void dynamics();                       // perform a dynamic update
   void output( char *bufL, char *bufR ); // output 1 buffer of audio
   void setXPanPos( byte xpanPos );       // set the xpan position : pan[0/3] 

   #ifdef KEYBRD_MENUS
   char menu( key k );                    // map key event to character
   #endif


} ;


#endif   // ifndef QUADSYNTH_H_INCLUDED
